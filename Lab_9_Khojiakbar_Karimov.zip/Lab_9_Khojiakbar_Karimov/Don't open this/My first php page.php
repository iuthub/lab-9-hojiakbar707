<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<?php
	echo '<strong>Hello world</strongy>';
	echo '<code>Hello world</code>';
	echo '<b>Hello world</b>';
	echo '<em>Hello world</em>';
	echo '<mark>Hello world</mark>';
	echo '<i>Hello world</i>';
	echo '<small>Hello world</small>';
	echo '<del>Hello world</del>';
	echo '<ins>Hello world</ins>';
	echo '<sup>Hello world</sup>';
	echo '<sub>Hello world</sub>';
	?>
	<?php
	$name='Ziyodakhon';
	$AGE=22;
	echo $name, $AGE;
	?>
	<?php
        define("NAME", "Ziyodakhon", true);
        echo name;
        ?>





</body>
</html>