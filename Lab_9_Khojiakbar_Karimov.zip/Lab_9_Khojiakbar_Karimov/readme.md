# Laravel - Getting Started
This repository holds the starting source code of the "PHP Development with Laravel - Working with Models & Data" course.

Clone this repository to start with the same code I start with in this course.

# Usage
Simply clone this repo and run `composer install` to install all the required dependencies. Make sure to rename the `.env.example` file to `.env` and also run `php artisan key:generate` to generate an application key for this Laravel app.
