<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="{{ route('blog.index') }}">Laravel Guide</a>
            <ul class="nav navbar-nav">
                <li class="active"><a href="{{ route('admin.index') }}">Posts</a></li>
            </ul>
        </div>
    </div><!-- /.container-fluid -->
</nav>
